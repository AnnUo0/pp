﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;


namespace WpfApp222
{
    /// <summary>
    /// Логика взаимодействия для App.xaml
    /// </summary>
    public partial class App : Application
    {

        public static serviceEntities GetContext {  get;  } = new serviceEntities();
        public static serviceEntities Context

        {  get; } = new serviceEntities();

        public static User CurrentUser = null;
        public static string Global {  get; set; }
    }
}
